﻿using HealthcareApp.Entities;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace HealthcareApp.Web.ViewModels
{
    public class AppointmentViewModel
    {
        public int AppointmentId { get; set; }

        [Required(ErrorMessage = "Select Patient")]
        public int PatientId { get; set; }

        [Required(ErrorMessage = "Select Doctor")]
        public int DoctorId { get; set; }

        public string? PatientName { get; set; }
        public string? DoctorName { get; set; }

        [Required(ErrorMessage = "Date is required")]
        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Time slot required")]
        public string? TimeSlot { get; set; }

        public AppointmentStatus Status { get; set; }

        public List<SelectListItem>? Patients { get; set; }
        public List<SelectListItem>? Doctors { get; set; }
    }
}
