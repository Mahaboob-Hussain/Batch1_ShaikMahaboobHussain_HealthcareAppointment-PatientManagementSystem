using System.Diagnostics;
using HealthcareApp.DAL;
using HealthcareApp.Web.Models;
using Microsoft.AspNetCore.Mvc;

namespace HealthcareApp.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            ViewBag.PatientCount = _context.Patients.Count();
            ViewBag.DoctorCount = _context.Doctors.Count();
            ViewBag.AppointmentCount = _context.Appointments.Count();

            return View();
        }
    }
}
