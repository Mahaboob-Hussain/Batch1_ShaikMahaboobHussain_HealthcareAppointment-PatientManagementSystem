﻿using HealthcareApp.BLL;
using HealthcareApp.DAL;
using HealthcareApp.Entities;
using HealthcareApp.Web.ViewModels;
using Humanizer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace HealthcareApp.Web.Controllers
{
    public class AppointmentController : Controller
    {
        private readonly AppointmentService _service;
        private readonly AppDbContext _context;

        public AppointmentController(AppointmentService service, AppDbContext context)
        {
            _service = service;
            _context = context;
        }


        public async Task<IActionResult> Index()
        {
            var data = await _service.GetAllAsync(); 

            var vmList = data.Select(a => new AppointmentViewModel
            {
                AppointmentId = a.AppointmentId,
                PatientId = a.PatientId,
                DoctorId = a.DoctorId,
                Date = a.Date,
                TimeSlot = a.TimeSlot,
                Status = a.Status,
                PatientName = a.Patient?.Name,
                DoctorName = a.Doctor?.Name

            }).ToList();

            return View(vmList); 
        }

        public async Task<IActionResult> Details(int id)
        {
            var appointment = await _context.Appointments
                .Include(a => a.Patient)
                .Include(a => a.Doctor)
                .FirstOrDefaultAsync(a => a.AppointmentId == id);

            if (appointment == null)
                return NotFound();

            var vm = new AppointmentViewModel
            {
                AppointmentId = appointment.AppointmentId,
                Date = appointment.Date,
                TimeSlot = appointment.TimeSlot,
                Status = appointment.Status,
                PatientName = appointment.Patient?.Name,
                DoctorName = appointment.Doctor?.Name
            };

            return View(vm);
        }

        public IActionResult Create()
        {
            var vm = new AppointmentViewModel
            {
                Patients = _context.Patients
                    .Select(p => new SelectListItem { Value = p.PatientId.ToString(), Text = p.Name })
                    .ToList(),

                Doctors = _context.Doctors
                    .Select(d => new SelectListItem { Value = d.DoctorId.ToString(), Text = d.Name })
                    .ToList()
            };

            return View(vm);
        }

        
        [HttpPost]
        public async Task<IActionResult> Create(AppointmentViewModel vm)
        {
            try
            {
                if(!ModelState.IsValid)
                {
                    vm.Patients = _context.Patients.Select(p => new SelectListItem
                    {
                        Value = p.PatientId.ToString(),
                        Text = p.Name
                    }).ToList();
                    vm.Doctors = _context.Doctors.Select(d => new SelectListItem
                    {
                        Value = d.DoctorId.ToString(),
                        Text = d.Name
                    }).ToList();
                    return View(vm);
                }
                var entity = new Appointment
                {
                    PatientId = vm.PatientId,
                    DoctorId = vm.DoctorId,
                    Date = vm.Date,
                    TimeSlot = vm.TimeSlot
                };

                await _service.BookAsync(entity);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);

                vm.Patients = _context.Patients.Select(p => new SelectListItem
                {
                    Value = p.PatientId.ToString(),
                    Text = p.Name
                }).ToList();

                vm.Doctors = _context.Doctors.Select(d => new SelectListItem
                {
                    Value = d.DoctorId.ToString(),
                    Text = d.Name
                }).ToList();

                return View(vm);
            }
        }


        public async Task<IActionResult> Edit(int id)
        {
            var appointment = await _context.Appointments
                .Include(a => a.Patient)
                .Include(a => a.Doctor)
                .FirstOrDefaultAsync(a => a.AppointmentId == id);

            if (appointment == null)
                return NotFound();

            var vm = new AppointmentViewModel
            {
                AppointmentId = appointment.AppointmentId,
                PatientId = appointment.PatientId,
                DoctorId = appointment.DoctorId,
                Date = appointment.Date,
                TimeSlot = appointment.TimeSlot,
                Status = appointment.Status,

                
                PatientName = appointment.Patient?.Name,
                DoctorName = appointment.Doctor?.Name
            };

            return View(vm);
        }


        [HttpPost]
        public async Task<IActionResult> Edit(AppointmentViewModel vm)
        {
            try
            {
                if (!ModelState.IsValid)
                    return View(vm);
                var entity = await _context.Appointments.FindAsync(vm.AppointmentId);

                if (entity == null)
                    return NotFound();


                entity.Status = vm.Status;

                await _context.SaveChangesAsync();

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(vm);
            }
        }
    }
}
