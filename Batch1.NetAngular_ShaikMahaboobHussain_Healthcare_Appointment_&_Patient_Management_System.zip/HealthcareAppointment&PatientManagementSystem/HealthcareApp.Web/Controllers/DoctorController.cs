﻿using HealthcareApp.BLL;
using HealthcareApp.BLL.DTOs;
using HealthcareApp.Entities;
using Humanizer;
using Microsoft.AspNetCore.Mvc;

namespace HealthcareApp.Web.Controllers
{
    public class DoctorController : Controller
    {
        private readonly DoctorService _service;
        public DoctorController(DoctorService service)
        {
            _service = service;
        }
        public async Task<IActionResult> Index()
        {
            return View(await _service.GetAllAsync());
        }
        public async Task<IActionResult> Details(int id)
        {
            return View(await _service.GetByIdAsync(id));
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(DoctorDTO dto)
        {
            try
            {
                if(!ModelState.IsValid)
                    return View(dto);
                await _service.AddAsync(dto);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(dto);
            }
        }
        public async Task<IActionResult> Edit(int id)
        {
            return View(await _service.GetByIdAsync(id));
        }
        [HttpPost]
        public async Task<IActionResult> Edit(DoctorDTO dto)
        {
            try
            {
                if (!ModelState.IsValid)
                    return View(dto);
                await _service.UpdateAsync(dto);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(dto);
            }
        }
        public async Task<IActionResult> Delete(int id)
        {
            return View(await _service.GetByIdAsync(id));
        }
        [HttpPost]
        public async Task<IActionResult> DeleteConformed(int id)
        {
            try
            {
                await _service.DeleteAsync(id);
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View();
            }
        }
    }
}
