﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HealthcareApp.Entities
{
    public class Doctor
    {
        public int DoctorId { get; set; }
        [Required]
        public string? Name {  get; set; }
        [Required]
        public string? Specialization {  get; set; }
        [Required]
        public string? AvailableTimeSlot {  get; set; }
    }
}
