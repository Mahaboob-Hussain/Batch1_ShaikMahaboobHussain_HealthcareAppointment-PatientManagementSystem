﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HealthcareApp.Entities
{
    public enum AppointmentStatus
    {
        Booked,
        Cancelled,
        Completed
    }

}
