﻿using System;
using System.Collections.Generic;
using System.Text;
using HealthcareApp.BLL.Mappers;
using HealthcareApp.BLL.DTOs;
using HealthcareApp.DAL;
using HealthcareApp.Entities;
using Microsoft.EntityFrameworkCore;

namespace HealthcareApp.BLL
{
    public class DoctorService
    {
        private readonly AppDbContext _context;
        public DoctorService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<DoctorDTO>> GetAllAsync()
        {
            var doctors=await _context.Doctors.ToListAsync();
            return doctors.Select(Mapper.ToDTO).ToList();
        }
        public async Task<DoctorDTO> GetByIdAsync(int id)
        {
            var doctor=await _context.Doctors.FindAsync(id);
            if (doctor == null)
            {
                throw new Exception("Doctor not Found");
            }
            return Mapper.ToDTO(doctor);
        }
        public async Task AddAsync(DoctorDTO dto)
        {
            var entity = Mapper.ToEntity(dto);
            await _context.Doctors.AddAsync(entity);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(DoctorDTO dto)
        {
            var entity = await _context.Doctors.FindAsync(dto.DoctorId);
            if (entity == null)
            {
                throw new Exception("Doctor Not Found");
            }
            entity.Name= dto.Name;
            entity.Specialization = dto.Specialization;
            entity.AvailableTimeSlot= dto.AvailableTimeSlot;
            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(int id)
        {
            var doctor = await _context.Doctors.FindAsync(id);
            if (doctor == null)
            {
                throw new Exception("Doctor Not Found");
            }
                _context.Doctors.Remove(doctor);
                await _context.SaveChangesAsync();
        }
    }
}
