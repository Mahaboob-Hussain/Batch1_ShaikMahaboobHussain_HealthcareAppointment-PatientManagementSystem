﻿using System;
using System.Collections.Generic;
using System.Text;
using HealthcareApp.DAL;
using HealthcareApp.Entities;
using Microsoft.EntityFrameworkCore;

namespace HealthcareApp.BLL
{
    public class AppointmentService
    {
        private readonly AppDbContext _context;
        public AppointmentService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Appointment>> GetAllAsync()
        {
            return await _context.Appointments.Include(a => a.Patient).Include(a => a.Doctor).ToListAsync();
        }
        public  async Task BookAsync(Appointment model)
        {
            if (model.Date.Date < DateTime.Today)
                throw new Exception("Appointment date cannot be in the past");

            bool exists = await _context.Appointments.AnyAsync(a =>
                a.DoctorId == model.DoctorId &&
                a.Date.Date == model.Date.Date &&
                a.TimeSlot == model.TimeSlot);

            if (exists)
            {
                throw new Exception("Time Slot already booked");
            }

            model.Status = AppointmentStatus.Booked;

            await _context.Appointments.AddAsync(model);
            await _context.SaveChangesAsync();
        }
        public async Task UpdaateStatusAsync(int id,AppointmentStatus status)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if (appointment == null)
            {
                throw new Exception("Appointment not found");
            }
            appointment.Status = status;
            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(int id)
        {
            var appointment = await _context.Appointments.FindAsync(id);
            if(appointment != null)
            {
                _context.Appointments.Remove(appointment);
                await _context.SaveChangesAsync();
            }
        }
    }
}
