﻿using System;
using System.Collections.Generic;
using System.Text;
using HealthcareApp.BLL.DTOs;
using HealthcareApp.Entities;

namespace HealthcareApp.BLL.Mappers
{
    public static class Mapper
    {
        public static PatientDTO ToDTO(Patient p) => new PatientDTO
        {
            PatientId=p.PatientId,
            Name=p.Name,
            Age=p.Age,
            PhoneNumber=p.PhoneNumber,
            Email=p.EMail,
            Gender = p.Gender,
            MedicalNotes=p.MedicalNotes,
        };
        public static Patient ToEntity(PatientDTO dto) => new Patient
        {
            PatientId = dto.PatientId,
            Name = dto.Name,
            Age = dto.Age,
            PhoneNumber = dto.PhoneNumber,
            EMail=dto.Email??"",
            Gender=dto.Gender,
            MedicalNotes=dto.MedicalNotes,
        };

        public static DoctorDTO ToDTO(Doctor d) => new DoctorDTO
        {
            DoctorId=d.DoctorId,
            Name=d.Name,
            Specialization=d.Specialization,
            AvailableTimeSlot=d.AvailableTimeSlot
        };
        public static Doctor ToEntity(DoctorDTO dto) => new Doctor
        {
            DoctorId= dto.DoctorId,
            Name=dto.Name,
            Specialization= dto.Specialization,
            AvailableTimeSlot = dto.AvailableTimeSlot
        };
    }
}
