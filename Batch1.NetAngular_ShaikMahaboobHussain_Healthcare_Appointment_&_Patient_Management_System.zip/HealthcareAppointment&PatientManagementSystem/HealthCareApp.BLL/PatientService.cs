﻿using HealthcareApp.BLL.DTOs;
using HealthcareApp.DAL;
using Microsoft.EntityFrameworkCore;
using HealthcareApp.BLL.Mappers;

namespace HealthcareApp.BLL
{
    public class PatientService
    {
        private readonly AppDbContext _context;
        private readonly IPatientDapperRepository _dapper;
        public PatientService(AppDbContext context,IPatientDapperRepository dapper)
        {
            _context = context;
            _dapper = dapper;
        }
        public async Task<List<PatientDTO>> GetAllAsync()
        {
            var data=await _dapper.GetAllAsync();
            return data.Select(Mapper.ToDTO).ToList();
        }
        public async Task<PatientDTO> GetbyIdAsync(int id)
        {
            var patient = await _context.Patients.FindAsync(id);
            if (patient == null)
            {
                throw new Exception("Patient Not Found");
            }
            return Mapper.ToDTO(patient);
        }
        public async Task AddAsync(PatientDTO dto)
        {
            try
            {
                if (await _context.Patients.AnyAsync(x => x.PhoneNumber == dto.PhoneNumber))
                    throw new Exception("phone already exists");
                var entity = Mapper.ToEntity(dto);
                await _context.Patients.AddAsync(entity);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception("DB ERROR: " + ex.InnerException?.Message ?? ex.Message);
            }
        }
        public async Task UpdateAsync(PatientDTO dto)
        {
            var entity = await _context.Patients.FindAsync(dto.PatientId);
            if(entity == null)
            {
                throw new Exception("Patient Not Found");
            }
            entity.Name= dto.Name;
            entity.Age= dto.Age;
            entity.PhoneNumber= dto.PhoneNumber;
            entity.EMail = dto.Email;
            entity.Gender= dto.Gender;
            entity.MedicalNotes= dto.MedicalNotes;

            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(int id)
        {
            var patient = await _context.Patients.FindAsync(id);
            if(patient == null)
            {
                throw new Exception("Patient Not Found");
            }
            _context.Patients.Remove(patient);
            await _context.SaveChangesAsync();
        }
    }
}
