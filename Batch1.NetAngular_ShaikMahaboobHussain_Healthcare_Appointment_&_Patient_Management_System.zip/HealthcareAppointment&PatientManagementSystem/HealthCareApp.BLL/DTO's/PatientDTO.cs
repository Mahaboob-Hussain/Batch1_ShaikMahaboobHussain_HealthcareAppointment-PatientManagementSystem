﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HealthcareApp.BLL.DTOs
{
    public class PatientDTO
    {
        public int PatientId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string? Name { get; set; }

        [Range(1, 120, ErrorMessage = "Age must be valid")]
        public int Age { get; set; }

        [Required]
        [RegularExpression(@"^[5-9][0-9]{9}$", ErrorMessage = "Invalid phone")]
        public string? PhoneNumber { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Invalid email")]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Gender required")]
        public string? Gender { get; set; }

        public string? MedicalNotes { get; set; }
    }
}
