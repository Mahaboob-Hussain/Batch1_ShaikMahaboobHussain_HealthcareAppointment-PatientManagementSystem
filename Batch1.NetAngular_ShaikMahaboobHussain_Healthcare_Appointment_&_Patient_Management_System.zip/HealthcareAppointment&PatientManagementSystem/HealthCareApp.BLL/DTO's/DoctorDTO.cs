﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HealthcareApp.BLL.DTOs
{
    public class DoctorDTO
    {
        public int DoctorId { get; set; }

        [Required(ErrorMessage = "Doctor name required")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Specialization required")]
        public string? Specialization { get; set; }

        [Required(ErrorMessage = "Time slot required")]
        public string? AvailableTimeSlot { get; set; }
    }
}
