﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Numerics;
using System.Text;
using Dapper;
using HealthcareApp.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace HealthcareApp.DAL
{
    public class AppointmentDapperRepository:IAppointmentDapperRepository
    {
        private readonly string _connection;
        public AppointmentDapperRepository(IConfiguration config)
        {
            _connection = config.GetConnectionString("DefaultConnection");
        }
        private IDbConnection CreateConnection()
        {
            return new SqlConnection(_connection);
        }

        public async Task<int> AddAsync(Appointment appointment)
        {
            try
            {
                using var db = CreateConnection();

                string sql = @"INSERT INTO Appointments
                          (PatientId, DoctorId, Date, TimeSlot, Status)
                          VALUES
                          (@PatientId, @DoctorId, @Date, @TimeSlot, @Status)";

                return await db.ExecuteAsync(sql, appointment);
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            try
            {
                using var db = CreateConnection();

                return await db.ExecuteAsync("DELETE FROM Appointments WHERE AppointmentId=@Id",new { Id = id });
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<IEnumerable<Appointment>> GetAllAsync()
        {
            try
            {
                using var db = CreateConnection();

                string sql = @"SELECT a.*, p.Name AS PatientName, d.Name AS DoctorNameFROM Appointments a JOIN Patients p ON a.PatientId = p.PatientId JOIN Doctors d ON a.DoctorId = d.DoctorId";

                return await db.QueryAsync<Appointment>(sql);
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<Appointment> GetByIdAsync(int id)
        {
            try
            {
                using var db = CreateConnection();

                return await db.QueryFirstOrDefaultAsync<Appointment>("SELECT * FROM Appointments WHERE AppointmentId=@Id",new { Id = id });

            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<bool> IsSlotBooked(int doctorId, DateTime date, string timeSlot)
        {
            try
            {
                using var db = CreateConnection();

                string sql = @"SELECT COUNT(1)
                           FROM Appointments
                           WHERE DoctorId=@DoctorId
                           AND CAST(Date AS DATE)=@Date
                           AND TimeSlot=@TimeSlot";

                int count = await db.ExecuteScalarAsync<int>(sql, new
                {
                    DoctorId = doctorId,
                    Date = date.Date,
                    TimeSlot = timeSlot
                });

                return count > 0;
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<int> UpdateAsync(Appointment appointment)
        {
            try
            {
                using var db = CreateConnection();

                string sql = @"UPDATE Appointments SET
                          PatientId=@PatientId,
                          DoctorId=@DoctorId,
                          Date=@Date,
                          TimeSlot=@TimeSlot,
                          Status=@Status
                          WHERE AppointmentId=@AppointmentId";

                return await db.ExecuteAsync(sql, appointment);
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }


    }
}
