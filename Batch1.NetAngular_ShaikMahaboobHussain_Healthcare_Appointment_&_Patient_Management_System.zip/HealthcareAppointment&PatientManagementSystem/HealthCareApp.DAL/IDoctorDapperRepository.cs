﻿using System;
using System.Collections.Generic;
using System.Text;
using HealthcareApp.Entities;

namespace HealthcareApp.DAL
{
    public interface IDoctorDapperRepository
    {
        Task<IEnumerable<Doctor>> GetAllAsync();
        Task<Doctor> GetByIdAsync(int id);
        Task<int> AddAsync(Doctor doctor);
        Task<int> UpdateAsync(Doctor doctor);
        Task<int> DeleteAsync(int id);
    }
}
