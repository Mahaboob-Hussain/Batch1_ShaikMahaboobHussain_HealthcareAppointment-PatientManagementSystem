﻿using System;
using System.Collections.Generic;
using System.Text;
using HealthcareApp.Entities;

namespace HealthcareApp.DAL
{
    public interface IPatientDapperRepository
    {
        Task<IEnumerable<Patient>> GetAllAsync();
        Task<Patient> GetByIdAsync(int id);
        Task<int> AddAsync(Patient patient);
        Task<int> UpdateAsync(Patient patient);
        Task<int> DeleteAsync(int id);
    }
}
