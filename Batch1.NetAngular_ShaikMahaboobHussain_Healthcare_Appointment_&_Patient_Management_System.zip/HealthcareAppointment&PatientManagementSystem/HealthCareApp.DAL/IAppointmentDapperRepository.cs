﻿using System;
using System.Collections.Generic;
using System.Text;
using HealthcareApp.Entities;

namespace HealthcareApp.DAL
{
    public interface IAppointmentDapperRepository
    {
        Task<IEnumerable<Appointment>> GetAllAsync();
        Task<Appointment> GetByIdAsync(int id);
        Task<int> AddAsync(Appointment appointment);
        Task<int> UpdateAsync(Appointment appointment);
        Task<int> DeleteAsync(int id);
        Task<bool> IsSlotBooked(int doctorId, DateTime date, string timeSlot);
    }
}
