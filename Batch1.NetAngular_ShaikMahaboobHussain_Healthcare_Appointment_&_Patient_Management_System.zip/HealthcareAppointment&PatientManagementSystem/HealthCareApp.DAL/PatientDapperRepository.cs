﻿using System;
using System.Collections.Generic;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Text;
using Dapper;
using HealthcareApp.Entities;
using Microsoft.Extensions.Configuration;

namespace HealthcareApp.DAL
{
    public class PatientDapperRepository : IPatientDapperRepository
    {
        private readonly string _connection;
        public PatientDapperRepository(IConfiguration config)
        {
            _connection = config.GetConnectionString("DefaultConnection")!;

            if (string.IsNullOrEmpty(_connection))
                throw new Exception("Connection string is NULL");
        }
        private IDbConnection CreateConnection()
        {
            return new SqlConnection(_connection);
        }
        public async Task<IEnumerable<Patient>> GetAllAsync()
        {
            try
            {
                using var db = CreateConnection();
                return await db.QueryAsync<Patient>("Select * from Patients");
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<Patient> GetByIdAsync(int id)
        {
            try
            {
                using var db = CreateConnection();
                return await db.QueryFirstOrDefaultAsync<Patient>("Select * from Patients where PatientId=@Id", new { Id = id });
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<int> AddAsync(Patient patient)
        {
            try
            {
                using var db = CreateConnection();
                string sql = @"Insert into Patients(Name,Age,Gender,PhoneNumber,Email,MedicalNotes) values(@Name, @Age, @Gender, @PhoneNumber, @EMail, @MedicalNotes)";
                return await db.ExecuteAsync(sql, patient);
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<int> UpdateAsync(Patient patient)
        {
            try
            {
                using var db = CreateConnection();
                string sql = @"Update Patients SET Name=@Name,Age=@Age,Gender=@Gender,PhoneNumber=@phoneNumber,MedicalNotes=@MedicalNotes Where PatientId=@PatientId";
                return await db.ExecuteAsync(sql, patient);
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            try
            {
                using var db = CreateConnection();
                return await db.ExecuteAsync("Delete from Patients where PatientId=@Id", new { Id = id });
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }
    }
}
