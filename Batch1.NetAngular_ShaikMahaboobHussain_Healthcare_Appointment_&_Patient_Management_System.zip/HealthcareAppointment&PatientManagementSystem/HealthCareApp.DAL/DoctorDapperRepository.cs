﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Dapper;
using HealthcareApp.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace HealthcareApp.DAL
{
    public class DoctorDapperRepository:IDoctorDapperRepository
    {
        private readonly string _connection;
        public DoctorDapperRepository(IConfiguration config)
        {
            _connection = config.GetConnectionString("DefaultConnection")!;
        }
        private IDbConnection CreateConnection()
        {
            return new SqlConnection(_connection);
        }


        public async Task<int> AddAsync(Doctor doctor)
        {
            try
            {
                using var db = CreateConnection();

                string sql = @"INSERT INTO Doctors
                          (Name, Specialization, AvailableTimeSlot)
                          VALUES
                          (@Name, @Specialization, @AvailableTimeSlot)";

                return await db.ExecuteAsync(sql, doctor);
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<int> DeleteAsync(int id)
        {
            try
            {
                using var db= CreateConnection();
                return await db.ExecuteAsync("DELETE FROM Doctors WHERE DoctorId=@Id",new { Id = id });
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<IEnumerable<Doctor>> GetAllAsync()
        {
            try
            {
                using var db = CreateConnection();
                return await db.QueryAsync<Doctor>("SELECT * FROM Doctors");
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<Doctor> GetByIdAsync(int id)
        {
            try
            {
                using var db = CreateConnection();
                return await db.QueryFirstOrDefaultAsync<Doctor>("SELECT * FROM Doctors WHERE DoctorId=@Id", new { Id = id });
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

        public async Task<int> UpdateAsync(Doctor doctor)
        {
            try
            {
                using var db = CreateConnection();

                string sql = @"UPDATE Doctors SET
                          Name=@Name,
                          Specialization=@Specialization,
                          AvailableTimeSlot=@AvailableTimeSlot
                          WHERE DoctorId=@DoctorId";

                return await db.ExecuteAsync(sql, doctor);
            }
            catch (Exception ex)
            {

                throw new Exception("Dapper Error: " + ex.ToString());
            }
        }

       
    }
}
